<?php

$conexion = new mysqli("localhost", "root", "", "240623");

$usuario = $_POST['username'];
$contra = $_POST['password'];
$confirmarContra = $_POST['confirm_password'];

$sentencia = "INSERT INTO usuarios VALUES ('$usuario', '$contra')";

$sql = "SELECT * FROM usuarios WHERE username = '$usuario'";
$result = $conexion->query($sql);

if ($result->num_rows == 0) {
    if ($contra == $confirmarContra) {
        echo "Usuario creado correctamente";
        $conexion->query($sentencia);
    } else {
        echo "Las contras no coinciden";
    }
} else {
    echo "Ya existe una persona con este nombre de usuario";
}



/*
if($conexion->query($sentencia) === TRUE)
header("Location: index.html?exito=true");
else
header("Location: index.html?exito=false");
*/
?>