<?php

$conexion = new mysqli("localhost", "root", "", "240623");

$usernameInput = $_POST['username'];
$passwordInput = $_POST['password'];

// Verificar si el usuario existe en la base de datos
$sql = "SELECT * FROM usuarios WHERE username = '$usernameInput'";
$result = $conexion->query($sql);

$password = "SELECT password FROM usuarios WHERE username = '$usernameInput'";
$resultPassword = $conexion->query($password);
$row = $resultPassword->fetch_assoc();
$ps = $row['password'];


if ($result->num_rows > 0) {

    if ($ps == $passwordInput) {
        echo "Inicio de sesión exitoso. ¡Bienvenido, $usernameInput!";
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "El usuario no existe en la base de datos.";
}

?>